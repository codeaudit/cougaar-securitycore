package PCSC_PACKAGE_NAME;


/**
 * Codes as defined for linux pcsc. If they differ from the windows one,
 * we have to map them either at runtime in the native code or
 * we have to set them correctly at initialization time.
 */
public class PCSC{
    /**
     * Note that PCSClite versions up to 0.8.2 return 1 on success
     * and thus do not match jpcsc.
     */
    public static int SUCCESS;

    /** Scope in user space */
    public static int SCOPE_USER;
    /** Scope in terminal   */
    public static int SCOPE_TERMINAL;
    /** Scope in system     */
    public static int SCOPE_SYSTEM;
    /**
     * SCOPE_GLOBAL is only available in Linux, under Windows it is mapped
     * to SCOPE_SYSTEM.
     */
    public static int SCOPE_GLOBAL;

    /** T=0 active protocol. */
    public static int PROTOCOL_T0;
    /** T=1 active protocol. */
    public static int PROTOCOL_T1;
    /** Raw active protocol. */
    public static int PROTOCOL_RAW;
    /**
     * PROTOCOL_ANY is not natively available under Windows, PROTOCOL_DEFAULT
     * not under Linux. Both are set to the same value by jpcsc.
     */
    public static int PROTOCOL_ANY;         
    public static int PROTOCOL_DEFAULT;     

    /** Ignore card-extended */
    public static int IGNORE_CARD;

    /** Exclusive mode only  */
    public static int SHARE_EXCLUSIVE;
    /** Shared mode only     */
    public static int SHARE_SHARED;
    /** Raw mode only */
    public static int SHARE_DIRECT;

    /** Do nothing on close  */
    public static int LEAVE_CARD;
    /** Reset on close       */
    public static int RESET_CARD;
    /** Power down on close  */
    public static int UNPOWER_CARD;
    /** Eject on close       */  
    public static int EJECT_CARD;

    /** Unknown state        */   
    public static int UNKNOWN;

    /** Card is absent       */
    public static int ABSENT;
    /** Card is present      */
    public static int PRESENT;
    /** Card not powered     */
    public static int SWALLOWED;
    /** Card is powered      */
    public static int POWERED;
    /** Ready for PTS        */
    public static int NEGOTIABLE;
    /** PTS has been set     */
    public static int SPECIFIC;

    /** App wants status     */
    public static int STATE_UNAWARE;
    /** Ignore this reader   */
    public static int STATE_IGNORE;
    /** State has changed    */
    public static int STATE_CHANGED;
    /** Reader unknown       */
    public static int STATE_UNKNOWN;
    /** Status unavailable   */
    public static int STATE_UNAVAILABLE;
    /** Card removed         */
    public static int STATE_EMPTY;
    /** Card inserted        */
    public static int STATE_PRESENT;
    /** ATR matches card 	*/
    public static int STATE_ATRMATCH;
    /** Exclusive Mode       */
    public static int STATE_EXCLUSIVE;
    /** Shared Mode          */
    public static int STATE_INUSE;
    /** Unresponsive card    */
    public static int STATE_MUTE;

    /**
     * Dummy constructor.
     */
    private PCSC(){}

#ifdef DEBUG
    /**
     * Print values of codes dependent on underlying platform.
     */
    public static void log(){
	System.out.println("Code.java:");
	System.out.println("SUCCESS: " + Integer.toHexString(PCSC.SUCCESS));
	System.out.println("SCOPE_USER: " + Integer.toHexString(PCSC.SCOPE_USER));
	System.out.println("SCOPE_TERMINAL: " + Integer.toHexString(PCSC.SCOPE_TERMINAL));
	System.out.println("SCOPE_SYSTEM: " + Integer.toHexString(PCSC.SCOPE_SYSTEM));
	System.out.println("SCOPE_GLOBAL: " + Integer.toHexString(PCSC.SCOPE_GLOBAL));
	System.out.println("PROTOCOL_T0: " + Integer.toHexString(PCSC.PROTOCOL_T0));
	System.out.println("PROTOCOL_T1: " + Integer.toHexString(PCSC.PROTOCOL_T1));
	System.out.println("PROTOCOL_RAW: " + Integer.toHexString(PCSC.PROTOCOL_RAW));
	System.out.println("PROTOCOL_ANY: " + Integer.toHexString(PCSC.PROTOCOL_ANY));
	System.out.println("PROTOCOL_DEFAULT: " + Integer.toHexString(PCSC.PROTOCOL_DEFAULT));
	System.out.println("IGNORE_CARD: " + Integer.toHexString(PCSC.IGNORE_CARD));
	System.out.println("SHARE_EXCLUSIVE: " + Integer.toHexString(PCSC.SHARE_EXCLUSIVE));
	System.out.println("SHARE_SHARED: " + Integer.toHexString(PCSC.SHARE_SHARED));
	System.out.println("SHARE_DIRECT: " + Integer.toHexString(PCSC.SHARE_DIRECT));
	System.out.println("LEAVE_CARD: " + Integer.toHexString(PCSC.LEAVE_CARD));
	System.out.println("RESET_CARD: " + Integer.toHexString(PCSC.RESET_CARD));
	System.out.println("UNPOWER_CARD: " + Integer.toHexString(PCSC.UNPOWER_CARD));
	System.out.println("EJECT_CARD: " + Integer.toHexString(PCSC.EJECT_CARD));
	System.out.println("UNKNOWN: " + Integer.toHexString(PCSC.UNKNOWN));
	System.out.println("ABSENT: " + Integer.toHexString(PCSC.ABSENT));
	System.out.println("PRESENT: " + Integer.toHexString(PCSC.PRESENT));
	System.out.println("SWALLOWED: " + Integer.toHexString(PCSC.SWALLOWED));
	System.out.println("POWERED: " + Integer.toHexString(PCSC.POWERED));
	System.out.println("NEGOTIABLE: " + Integer.toHexString(PCSC.NEGOTIABLE));
	System.out.println("SPECIFIC: " + Integer.toHexString(PCSC.SPECIFIC));
	System.out.println("STATE_UNAWARE: " + Integer.toHexString(PCSC.STATE_UNAWARE));
	System.out.println("STATE_IGNORE: " + Integer.toHexString(PCSC.STATE_IGNORE));
	System.out.println("STATE_CHANGED: " + Integer.toHexString(PCSC.STATE_CHANGED));
	System.out.println("STATE_UNKNOWN: " + Integer.toHexString(PCSC.STATE_UNKNOWN));
	System.out.println("STATE_UNAVAILABLE: " + Integer.toHexString(PCSC.STATE_UNAVAILABLE));
	System.out.println("STATE_EMPTY: " + Integer.toHexString(PCSC.STATE_EMPTY));
	System.out.println("STATE_PRESENT: " + Integer.toHexString(PCSC.STATE_PRESENT));
	System.out.println("STATE_ATRMATCH: " + Integer.toHexString(PCSC.STATE_ATRMATCH));
	System.out.println("STATE_EXCLUSIVE: " + Integer.toHexString(PCSC.STATE_EXCLUSIVE));
	System.out.println("STATE_INUSE: " + Integer.toHexString(PCSC.STATE_INUSE));
	System.out.println("STATE_MUTE: " + Integer.toHexString(PCSC.STATE_MUTE));
    }
#endif /* DEBUG */
}
