#include "jpcsc.h"

void pcscex_throw(JNIEnv *env, const char *cn, const char *msg){
    jclass excl;
    int ret;

    excl = (*env)->FindClass(env, cn);
    assert(excl != NULL);

    ret = (*env)->ThrowNew(env, excl, msg);
    assert(ret == 0);
}


#ifdef DEBUG
void pcsc_readerstatea_log(SCARD_READERSTATE_A *rsa){
    int i;
    fprintf(stderr, "SCARD_READERSTATE_A: at 0x%x\n", rsa);
    fprintf(stderr, "reader: %s\n", rsa->szReader); 
    fprintf(stderr, "user data: 0x%x\n", rsa->pvUserData);
    fprintf(stderr, "current state: 0x%x\n", rsa->dwCurrentState);
    fprintf(stderr, "event state: 0x%x\n", rsa->dwEventState);
    fprintf(stderr, "atr: len %d", rsa->cbAtr);
    if (rsa->cbAtr > 0){
	for (i = 0; i < rsa->cbAtr; i++){
	    fprintf(stderr, "0x%x, ", rsa->cbAtr & 0xff);
	}
    }
    fprintf(stderr, "\n");
}
#endif /* DEBUG */
