import com.linuxnet.jpcsc.*;

public class Test{
    static final int GETSTATUSCHANGE_TEST = 0;
    static final int PASSTHROUGH_TEST = 1;
    static final int STRESS_TEST = 2;
    
    public static void main(String[] args){
	int mode = PASSTHROUGH_TEST;
	
	if (args.length > 0){
	    try{
		mode = Integer.decode(args[0]).intValue();
	    }catch(Exception e){}
	}

	if (mode == STRESS_TEST){
	    stressTest();
	    return;
	}

	System.out.println("EstablishContext ...");
	Context ctx = new Context();
	//System.out.println("List Codes ...");
	//PCSC.log();
	ctx.EstablishContext(PCSC.SCOPE_SYSTEM, null, null);
	
	System.out.println("ListReaders ...");
	String[] sa = ctx.ListReaders();
	if (sa.length == 0){
	    throw new RuntimeException("no reader found");
	}
	for (int i = 0; i < sa.length; i++){
	    System.out.println("Reader: " + sa[i]);
	}

	if (mode == GETSTATUSCHANGE_TEST){
	    System.out.println("GetStatusChange: ...");
	    State[] rsa = new State[1];
	    rsa[0] = new State(sa[0]);	   
	    do{
		ctx.GetStatusChange(1000, rsa);
		System.out.println("ReaderState: " + rsa[0]);
		try{
		    Thread.currentThread().sleep(500);
		}catch(Exception e){}
	    }while(true);
	    // unreached
	}

	System.out.println("GetStatusChange: ...");
	State[] rsa = new State[1];
	rsa[0] = new State(sa[0]);
	do{
	    ctx.GetStatusChange(1000, rsa);
	}while((rsa[0].dwEventState & PCSC.STATE_PRESENT) != PCSC.STATE_PRESENT);
	System.out.println("ReaderState: " + rsa[0]);

	System.out.println("Connect: ...");
	Card c = ctx.Connect(sa[0], PCSC.SHARE_EXCLUSIVE, 
			     PCSC.PROTOCOL_T1 | PCSC.PROTOCOL_T0);

	System.out.println("CardStatus: ...");
	State rs = c.Status();
	System.out.println("CardStatus: " + rs);

	// Full select APDU for CardDomain.
	byte[] ba = { 
	    (byte)0x00, (byte) 0xA4, (byte) 0x04, (byte) 0x00,  // select
	    (byte) 0x07, // length
	    (byte) 0xA0, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x03, (byte) 0x00, (byte) 0x00, (byte) 0x00, // AID 
	};

	System.out.println("Transmit1: ");
	byte[] ba2 = c.Transmit(ba, 0, ba.length);
	print(ba2);

	ba2 = new byte[256];
	System.out.println("Transmit2: ");
	int cnt = c.Transmit(ba, 0, ba.length, ba2, 0);
	print(ba2, 0, cnt);

	System.out.println("Reconnect: ...");
	c.Reconnect(PCSC.SHARE_EXCLUSIVE, PCSC.PROTOCOL_T1 | PCSC.PROTOCOL_T0, PCSC.RESET_CARD);

	System.out.println("CardStatus: ...");
	rs = c.Status();
	System.out.println("CardStatus: " + rs);

	byte[] ba3 = { (byte) 0xA0, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x03,
		       (byte) 0x00, (byte) 0x00, };
	System.out.println("Transmit3: ");
	ba = c.Transmit(0x00, 0xA4, 0x04, 0x00, ba3, 20);
	print(ba);
	
	System.out.println("Leaving ...");
	c.Disconnect(PCSC.LEAVE_CARD);
	ctx.ReleaseContext();
    }


    static void print(byte[] response){
	print(response, 0, response.length);
    }

    static void print(byte[] response, int off, int length){
	System.out.print("response: ");
	if (response != null){
	    System.out.print("len " + length + ", ");
	    for (int i = off; i < length; i++){
		System.out.print("0x" + Integer.toHexString(response[i] & 0xff) + ", ");
	    }
	}else{
	    System.out.print(" null");
	}
	System.out.println("");
    }

    public static int MAX_PASS_CNT = 100;
    
    static void stressTest(){
	System.out.println("Stress-Test: ...");
	int pass = 0;

	try{
	    while(pass < MAX_PASS_CNT){
		pass++;
		System.out.println("Pass: " + pass);
		
		Context ctx = new Context();
		ctx.EstablishContext(PCSC.SCOPE_SYSTEM, null, null);
	
		String[] sa = ctx.ListReaders();
		if (sa.length == 0){
		    throw new RuntimeException("no reader found");
		}
		System.out.println("Connect to reader: " + sa[0]);
		
		State[] rsa = new State[1];
		rsa[0] = new State(sa[0]);
		do{
		    ctx.GetStatusChange(1000, rsa);
		}while((rsa[0].dwEventState & PCSC.STATE_PRESENT) != PCSC.STATE_PRESENT);
		
		Card card = ctx.Connect(sa[0], PCSC.SHARE_EXCLUSIVE, 
					PCSC.PROTOCOL_T1 | PCSC.PROTOCOL_T0);
		State rs = card.Status();
		
		System.out.println("Select VOP on card");
		byte[] aid = { (byte) 0xA0, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x03,
			       (byte) 0x00, (byte) 0x00, };
		byte[] ret = card.Transmit(0x00, 0xA4, 0x04, 0x00, aid, 20);
		
		card.Disconnect(PCSC.LEAVE_CARD);

		ctx.ReleaseContext();
	    }
	}catch(Exception e){
	    System.out.println("Stress-Test: failed in pass " + pass);
	    System.out.println("Stress-Test: exception-type " + e.getClass().getName());
	    System.out.println("Stress-Test: exception-msg " + e.getMessage());
	    e.printStackTrace(System.out);
	    return;
	}
	System.out.println("Stress-Test: passed successfully !");
    }
}
