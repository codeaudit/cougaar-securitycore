package PCSC_PACKAGE_NAME;


/**
 * Exception class used for PCSC-related errors.
 */
public class PCSCException extends RuntimeException{
    /**
     * Default constructor.
     */
    public PCSCException(){}

    /**
     * Default constructor.
     */
    public PCSCException(String msg){
	super(msg);
    }

    
}
