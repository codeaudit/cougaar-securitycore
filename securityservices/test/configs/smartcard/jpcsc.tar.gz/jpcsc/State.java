package PCSC_PACKAGE_NAME;

/**
 * Instances are used to keep information about the states
 * of connections with readers or cards.
 */
public class State{
    /**
     * The name of the reader. Has to be set for Context.GetStatusChange() 
     * and is returned by Card.Status().
     */
    public String szReader;

    /**
     * Not used.
     */
    public Object pvUserData;
    
    /**
     * Set by Context.GetStatusChange() and Card.Status().
     */
    public int dwCurrentState;

    /**
     * Only set via Context.GetStatusChange().
     */
    public int dwEventState;

    /**
     * The ATR received by a card. This array is always created by
     * the called native mthod.
     */
    public byte[] rgbAtr;

    /**
     * Only set via Card.Status().
     */
    public int proto;


    /**
     * Constructor. Make sure that szReader is a proper
     * string.
     */
    public State(String szReader){
	if (szReader == null){
	    throw new NullPointerException();
	}
	this.szReader = szReader;
    }

    /**
     * Default constructor. Not externally visible.
     * Thus, szReader must never be checked in the JNI
     * layer for Context.GetStatusChange(), but State 
     * can still be used for Card.Status().
     */
    State(){}


    /**
     * Return a string representation.
     */
    public String toString(){
	StringBuffer sb = new StringBuffer();
	sb.append("reader: ").append(szReader).append('\n');
	sb.append("dwCurrentState: 0x").append(Integer.toHexString(dwCurrentState)).append('\n');
	sb.append("dwEventState: 0x").append(Integer.toHexString(dwEventState)).append('\n');
	sb.append("rgbAtr: ");

	if (rgbAtr == null){
	    sb.append("null\n");
	}else{
	    sb.append("atrlen " + rgbAtr.length + "  ");
	    for (int i = 0; i < rgbAtr.length; i++){
		sb.append(Integer.toHexString(rgbAtr[i] & 0xff));
	    }
	    sb.append("    ");
	    for (int i = 0; i < rgbAtr.length; i++){
		char c = (char) rgbAtr[i];
		if (Character.isLetterOrDigit(c)){
		    sb.append(c);
		}else{
		    if (Character.isWhitespace(c)){
			sb.append(' ');
		    }else{
			sb.append('X');
		    }
		}
	    }
	    sb.append('\n');
	}
	
	sb.append("proto: ").append(Integer.toHexString(proto));;
	
	return sb.toString();
    }
}
