package PCSC_PACKAGE_NAME;

import java.security.*;

/**
 * The Context-class wraps the PCSC-functions related to 
 * connecting/disconnecting to the PCSC-service
 * and card-readers. An invocation of Connect() returns
 * a connection to a Card allowing for the transmission
 * of APDUs.
 */
public class Context{

    static {
        AccessController.doPrivileged(new PrivilegedLoadLibrary());

	NativeInitialize(PCSC.class, Card.class, State.class);
    }


    /**
     * The native handle.
     */
    long ctx;


    /**
     * Constructor. Try to use established contexts as much as possible.
     * This keeps the number of underlying connections to the PCSC-daemon
     * low.
     */
    public Context(){}

    
    /**
     * Cleanup operation. Destroy context we have.
     */
    public final void finalize(){
#ifdef DEBUG
	System.err.println("Context.finalize(): release context ...");
#endif
	NativeReleaseContext();
    }


    /**
     * Establish context.
     */
    public final void EstablishContext(int dwScope, String pvReserved1, String pvReserved2){
	int ret = NativeEstablishContext(dwScope, pvReserved1, pvReserved2);
#ifdef DEBUG
	System.err.println("Context.Establish(): return " + ret);
#endif
	if (ret != PCSC.SUCCESS){
	    throw new PCSCException("EstablishContext(): " + StringifyError(ret));
	}
    }


    /**
     * Release context.
     */
    public final void ReleaseContext(){
	int ret = NativeReleaseContext();
#ifdef DEBUG
	System.err.println("Context.Release(): return " + ret);
#endif
	if (ret != PCSC.SUCCESS){
	    throw new PCSCException("ReleaseContext(): " + StringifyError(ret));
	}
    }
    

    /**
     * List all known readers. Note that reader groups are not supported.
     */
    public final String[] ListReaders(){
	String[] sa = NativeListReaders();
#ifdef DEBUG
	System.err.println("Context.ListReaders(): cnt " + ((sa == null) ? 0 : sa.length));
#endif
	if (sa == null){
	    return new String[0];
	}
#ifdef DEBUG
	for (int i = 0; i < sa.length; i++){
	    System.err.println("Reader " + i + ": " + sa[i]);
	}
#endif
	return sa;
    }


    /**
     * Return status change for given readers.
     */
    public final void GetStatusChange(int timeout, State[] readerStates){
	if (readerStates == null){
	    throw new NullPointerException();
	}
	int ret = NativeGetStatusChange(timeout, readerStates);
#ifdef DEBUG
	System.out.println("Context.GetStatusChange(): ret " + ret);
	if (ret == PCSC.SUCCESS){
	    for (int i = 0; i < readerStates.length; i++){
		System.err.println("ReaderState: " + i + ": " + readerStates[i]);
	    }
	}
#endif
	if (ret != PCSC.SUCCESS){
	    throw new PCSCException("GetStatusChange(): " + StringifyError(ret));
	}
    }


    /**
     * Return card object in case of successful connection.
     */
    public final Card Connect(String szReader, int dwShareMode, int dwPreferredProtocols){
	if (szReader == null){
	    throw new NullPointerException();
	}
	Card c = new Card();
	int ret = NativeConnect(c, szReader, dwShareMode, dwPreferredProtocols);
#ifdef DEBUG
	System.out.println("Context.Connect(): rdr " + szReader + ", share " +
			   dwShareMode + ", proto " + dwPreferredProtocols +
			   ", ret " + ret);
#endif
	if (ret != PCSC.SUCCESS){
	    throw new PCSCException("Connect(): " + StringifyError(ret));
	}
	return c;
    }


    /**
     * Cancel all pending GetStatusChange() calls.
     */
    public final void Cancel(){
	int ret = NativeCancel();
#ifdef DEBUG
	System.out.println("Context.Cancel(): ret " + ret);
#endif
	if (ret != PCSC.SUCCESS){
	    throw new PCSCException("Cancel(): " + StringifyError(ret));
	}
    }


    /**
     * Return symbolic representation of an error. Uses
     * pcsc_stringify_error().
     */
    public native static String StringifyError(int code);


    static native void NativeInitialize(Class codesClass, Class cardClass, Class readerStateClass);

    native int NativeEstablishContext(int dwScope, String pvReserved1, String pvReserved2);

    native int NativeCancel();

    native int NativeReleaseContext();
    
    native String[] NativeListReaders();

    native int NativeGetStatusChange(int timeout, State[] readerStates);

    native int NativeConnect(Card card, String szReader, int dwShareMode, int dwPreferredProtocols);


}
