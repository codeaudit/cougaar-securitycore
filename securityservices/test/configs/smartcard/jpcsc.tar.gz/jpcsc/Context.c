#include "jpcsc.h"

#include <stdlib.h>
#include <string.h>

jfieldID ctxField;
jfieldID cardField;
jfieldID protoField;

jfieldID readerStateField;
jfieldID currentStateField;
jfieldID eventStateField;
jfieldID protoStateField;
jfieldID atrStateField;

#define PCSC_PACKAGE_NAME com_linuxnet_jpcsc_

JNIEXPORT void JNICALL GEN_FUNCNAME(Context_NativeInitialize)
  (JNIEnv *env, jclass _this, jclass pcscClass, jclass cardClass, jclass stateClass)
{
    jclass contextClass = _this;
    jfieldID jfid;
    assert(contextClass != NULL);

    ctxField = (*env)->GetFieldID(env, contextClass, "ctx", "J");
    assert(ctxField != NULL);
    cardField = (*env)->GetFieldID(env, cardClass, "card", "J");
    assert(cardField != NULL);
    protoField = (*env)->GetFieldID(env, cardClass, "proto", "I");
    assert(protoField != NULL);

    readerStateField = (*env)->GetFieldID(env, stateClass, "szReader", "Ljava/lang/String;");
    assert(readerStateField != NULL);
    currentStateField = (*env)->GetFieldID(env, stateClass, "dwCurrentState", "I");
    assert(currentStateField != NULL);
    eventStateField = (*env)->GetFieldID(env, stateClass, "dwEventState", "I");
    assert(eventStateField != NULL);
    atrStateField = (*env)->GetFieldID(env, stateClass, "rgbAtr", "[B");
    assert(atrStateField != NULL);
    protoStateField = (*env)->GetFieldID(env, stateClass, "proto", "I");
    assert(protoStateField != NULL);

    // Set the different flags, they might differ between the different
    // underlying platforms as in case of Java or Windows
    jfid = (*env)->GetStaticFieldID(env, pcscClass, "SUCCESS", "I");
    assert(jfid != NULL);
    // SCARD_S_SUCCESS must be 0 for now
    if ((*env)->GetStaticIntField(env, pcscClass, jfid) != 0x0){
	pcscex_throw(env, PCSC_EX_CLASSNAME, "Invalid target platform: SCARD_S_SUCCESS != 0");
	return;
    }
#define SET_CODES_FIELD(field_name, field_value) \
    jfid = (*env)->GetStaticFieldID(env, pcscClass, field_name, "I");  \
    assert(jfid != NULL);            \
    (*env)->SetStaticIntField(env, pcscClass, jfid, field_value);  

    SET_CODES_FIELD("SCOPE_USER", SCARD_SCOPE_USER);
    SET_CODES_FIELD("SCOPE_TERMINAL", SCARD_SCOPE_TERMINAL);
    SET_CODES_FIELD("SCOPE_SYSTEM", SCARD_SCOPE_SYSTEM);

    SET_CODES_FIELD("PROTOCOL_T0", SCARD_PROTOCOL_T0);
    SET_CODES_FIELD("PROTOCOL_T1", SCARD_PROTOCOL_T1);
    SET_CODES_FIELD("PROTOCOL_RAW", SCARD_PROTOCOL_RAW);

    SET_CODES_FIELD("SHARE_EXCLUSIVE", SCARD_SHARE_EXCLUSIVE);
    SET_CODES_FIELD("SHARE_SHARED", SCARD_SHARE_SHARED);
    SET_CODES_FIELD("SHARE_DIRECT", SCARD_SHARE_DIRECT);

    SET_CODES_FIELD("LEAVE_CARD", SCARD_LEAVE_CARD);
    SET_CODES_FIELD("RESET_CARD", SCARD_RESET_CARD);
    SET_CODES_FIELD("UNPOWER_CARD", SCARD_UNPOWER_CARD);
    SET_CODES_FIELD("EJECT_CARD", SCARD_EJECT_CARD);

    SET_CODES_FIELD("UNKNOWN", SCARD_UNKNOWN);
    SET_CODES_FIELD("ABSENT", SCARD_ABSENT);
    SET_CODES_FIELD("PRESENT", SCARD_PRESENT);
    SET_CODES_FIELD("SWALLOWED", SCARD_SWALLOWED);
    SET_CODES_FIELD("POWERED", SCARD_POWERED);
    SET_CODES_FIELD("NEGOTIABLE", SCARD_NEGOTIABLE);
    SET_CODES_FIELD("SPECIFIC", SCARD_SPECIFIC);

    SET_CODES_FIELD("STATE_UNAWARE", SCARD_STATE_UNAWARE);
    SET_CODES_FIELD("STATE_IGNORE", SCARD_STATE_IGNORE);
    SET_CODES_FIELD("STATE_CHANGED", SCARD_STATE_CHANGED);
    SET_CODES_FIELD("STATE_UNKNOWN", SCARD_STATE_UNKNOWN);
    SET_CODES_FIELD("STATE_UNAVAILABLE", SCARD_STATE_UNAVAILABLE);
    SET_CODES_FIELD("STATE_EMPTY", SCARD_STATE_EMPTY);
    SET_CODES_FIELD("STATE_PRESENT", SCARD_STATE_PRESENT);
    SET_CODES_FIELD("STATE_ATRMATCH", SCARD_STATE_ATRMATCH);
    SET_CODES_FIELD("STATE_EXCLUSIVE", SCARD_STATE_EXCLUSIVE);
    SET_CODES_FIELD("STATE_INUSE", SCARD_STATE_INUSE);
    SET_CODES_FIELD("STATE_MUTE", SCARD_STATE_MUTE);

    jfid = (*env)->GetStaticFieldID(env, pcscClass, "SCOPE_GLOBAL", "I");
    assert(jfid != NULL);
#ifdef SCARD_SCOPE_GLOBAL
    (*env)->SetStaticIntField(env, pcscClass, jfid, SCARD_SCOPE_GLOBAL);
#else
    (*env)->SetStaticIntField(env, pcscClass, jfid, SCARD_SCOPE_SYSTEM);
#endif /* SCARD_SCOPE_GLOBAL */


    jfid = (*env)->GetStaticFieldID(env, pcscClass, "PROTOCOL_ANY", "I");
    assert(jfid != NULL);
#ifdef SCARD_PROTOCOL_ANY
    (*env)->SetStaticIntField(env, pcscClass, jfid, SCARD_PROTOCOL_ANY);
    jfid = (*env)->GetStaticFieldID(env, pcscClass, "PROTOCOL_DEFAULT", "I");
    assert(jfid != NULL);
    (*env)->SetStaticIntField(env, pcscClass, jfid, SCARD_PROTOCOL_ANY);
#else
    (*env)->SetStaticIntField(env, pcscClass, jfid, SCARD_PROTOCOL_DEFAULT);
    jfid = (*env)->GetStaticFieldID(env, pcscClass, "PROTOCOL_DEFAULT", "I");
    assert(jfid != NULL);
    (*env)->SetStaticIntField(env, pcscClass, jfid, SCARD_PROTOCOL_DEFAULT);
#endif /* SCARD_SCOPE_GLOBAL */

    
}

JNIEXPORT jint JNICALL GEN_FUNCNAME(Context_NativeEstablishContext)
  (JNIEnv *env, jobject _this, jint dwScope, jstring pvReserved1, jstring pvReserved2)
{
    int rv;
    SCARDCONTEXT ctx;
    LPCSTR pv1, pv2;
    jboolean b;

    pv1 = (pvReserved1 == NULL) ? NULL : (*env)->GetStringUTFChars(env, pvReserved1, &b);
    pv2 = (pvReserved2 == NULL) ? NULL : (*env)->GetStringUTFChars(env, pvReserved2, &b);
    
    rv = SCardEstablishContext(dwScope, pv1, pv2, &ctx);
  
    if (pv1 != NULL){
	(*env)->ReleaseStringUTFChars(env, pvReserved1, pv1);
    }
    if (pv2 != NULL){
	(*env)->ReleaseStringUTFChars(env, pvReserved2, pv2);
    }
    
    if (rv == SCARD_S_SUCCESS){
	(*env)->SetLongField(env, _this, ctxField, (jlong) ctx);
    }

    return rv;
}

JNIEXPORT jint JNICALL GEN_FUNCNAME(Context_NativeReleaseContext)
  (JNIEnv *env, jobject _this)
{
    SCARDCONTEXT ctx;

    ctx = (SCARDCONTEXT) (*env)->GetLongField(env, _this, ctxField);
    
    return SCardReleaseContext(ctx);
}


JNIEXPORT jobjectArray JNICALL GEN_FUNCNAME(Context_NativeListReaders)
  (JNIEnv *env, jobject _this)
{
    jclass stringClass = (*env)->FindClass(env, "java/lang/String");
    SCARDCONTEXT ctx;
    LPSTR mszReaders, cp;
    LONG rv;
    DWORD sz;
    char *rdrNames[JPCSC_MAX_RDRS];
    int rdrCnt;
    jobjectArray result;
    jstring jrdrName;

    ctx = (SCARDCONTEXT) (*env)->GetLongField(env, _this, ctxField);
    rv = SCardListReaders(ctx, NULL, NULL, &sz);
    if (rv != SCARD_S_SUCCESS){
	pcscex_throw(env, PCSC_EX_CLASSNAME, "SCardListReaders() failed !");
	return NULL;
    }

    mszReaders = (char *)malloc(sz);
    assert(mszReaders);

    rv = SCardListReaders(ctx, NULL, mszReaders, &sz);

    if (rv != SCARD_S_SUCCESS){
	free(mszReaders);
	pcscex_throw(env, PCSC_EX_CLASSNAME, "SCardListReaders() failed !");
	return NULL;
    }

    rdrCnt = 0;
    cp = mszReaders;
    while(*cp != 0){
	rdrNames[rdrCnt++] = cp;
	cp += (strlen(cp) + 1);
	if (rdrCnt > JPCSC_MAX_RDRS){
	    free(mszReaders);
	    pcscex_throw(env, PCSC_EX_CLASSNAME, "SCardListReaders(): too many readers !");
	    return NULL;
	}
    }
    
    result = (*env)->NewObjectArray(env, rdrCnt, stringClass, NULL);
    while(rdrCnt-- > 0){
	jrdrName = (*env)->NewStringUTF(env, rdrNames[rdrCnt]);
	(*env)->SetObjectArrayElement(env, result, rdrCnt, jrdrName);
    }

    free(mszReaders);
    return result;
}


JNIEXPORT jint JNICALL GEN_FUNCNAME(Context_NativeGetStatusChange)
  (JNIEnv *env, jobject _this, jint timeout, jobjectArray jrstates)
{
    SCARDCONTEXT ctx;
    SCARD_READERSTATE crstates[16];
    jobject jrdrName;
    jobject jrstate;
    jboolean isCopy;
    jbyteArray jatr;
    int crcnt;
    char *catr;
    int i;
    DWORD rv;

    ctx = (SCARDCONTEXT) (*env)->GetLongField(env, _this, ctxField);

    crcnt = (*env)->GetArrayLength(env, jrstates);
    if (crcnt > JPCSC_MAX_RDRS){
	pcscex_throw(env, PCSC_EX_CLASSNAME, "GetStatusChange(): too many reader-states !");
	return SCARD_E_INVALID_PARAMETER;
    }

    for (i = 0; i < crcnt; i++){
	jrstate = (*env)->GetObjectArrayElement(env, jrstates, i);
	if (jrstate == NULL){
	    pcscex_throw(env, NP_EX_CLASSNAME, "GetStatusChange(): ReaderState-array-entry is null");
	    return SCARD_E_INVALID_PARAMETER;
	}

	crstates[i].dwCurrentState = (*env)->GetIntField(env, jrstate, currentStateField);
	crstates[i].dwEventState = (*env)->GetIntField(env, jrstate, eventStateField);

	jrdrName = (*env)->GetObjectField(env, jrstate, readerStateField);
	crstates[i].szReader = (*env)->GetStringUTFChars(env, jrdrName, &isCopy);

	// Copy ATR. Check its size.
	jatr = (jbyteArray) (*env)->GetObjectField(env, jrstate, atrStateField);
	if (jatr != NULL){
	    catr = (*env)->GetByteArrayElements(env, jatr, &isCopy);
	    crstates[i].cbAtr = (*env)->GetArrayLength(env, jatr);
	    if (crstates[i].cbAtr > JPCSC_ATR_SIZE){
		pcscex_throw(env, NP_EX_CLASSNAME, "GetStatusChange(): ATR-length invalid");
		return SCARD_E_INVALID_PARAMETER;
	    }
	    memcpy(&crstates[i].rgbAtr[0], catr, crstates[i].cbAtr);
	    (*env)->ReleaseByteArrayElements(env, jatr, catr, JNI_ABORT);
	}

    }

    rv = SCardGetStatusChange(ctx, timeout, &crstates[0], crcnt);

    if (rv != SCARD_S_SUCCESS){
	return rv;
    }

    //pcsc_readerstatea_log(&crstates[0]);

    for (i = 0; i < crcnt; i++){
	jrstate = (*env)->GetObjectArrayElement(env, jrstates, i);
	(*env)->SetIntField(env, jrstate, currentStateField, crstates[i].dwCurrentState);
	(*env)->SetIntField(env, jrstate, eventStateField, crstates[i].dwEventState);
	jrdrName = (*env)->GetObjectField(env, jrstate, readerStateField);
	(*env)->ReleaseStringUTFChars(env, jrdrName, crstates[i].szReader);

	jatr = (*env)->NewByteArray(env, crstates[i].cbAtr);
	(*env)->SetByteArrayRegion(env, jatr, 0, crstates[i].cbAtr, crstates[i].rgbAtr);
	(*env)->SetObjectField(env, jrstate, atrStateField, jatr);
    }

    return rv;
}

JNIEXPORT jint JNICALL GEN_FUNCNAME(Context_NativeConnect)
  (JNIEnv *env, jobject _this, jobject _card, jstring jrdrName, jint dwSharedMode, jint dwPreferredProtocols)
{
    SCARDCONTEXT ctx;
    SCARDHANDLE card;
    const char *crdrName;
    jboolean isCopy;
    DWORD proto;
    LONG rv;

    crdrName = (*env)->GetStringUTFChars(env, jrdrName, &isCopy);

    ctx = (SCARDCONTEXT) (*env)->GetLongField(env, _this, ctxField);

    rv = SCardConnect(ctx, crdrName, dwSharedMode, dwPreferredProtocols, &card, &proto);

    (*env)->ReleaseStringUTFChars(env, jrdrName, crdrName);

    if (rv != SCARD_S_SUCCESS){
	return rv;
    }

    (*env)->SetLongField(env, _card, cardField, card);
    (*env)->SetIntField(env, _card, protoField, proto);

    return rv;
}


JNIEXPORT jint JNICALL GEN_FUNCNAME(Context_NativeCancel)
  (JNIEnv *env, jobject _this)
{
    SCARDCONTEXT ctx = (SCARDCONTEXT) (*env)->GetLongField(env, _this, ctxField);
    return SCardCancel(ctx);
}


JNIEXPORT jstring JNICALL GEN_FUNCNAME(Context_StringifyError)
  (JNIEnv *env, jclass _this, jint err)
{
#ifdef WIN32
    static const char* sev[4] = { "OK", "Info", "Warning", "Error" };
    char str[256];
    char *errstr = NULL;
    int len = 0;

    if ((err & 0xFFF0000) == 0x100000){
	switch(err & 0xFFFF){
	case 0x0009: errstr = "Unknown card terminal"; break;
	case 0x000A: errstr = "Time out"; break;
	case 0x000B: errstr = "Sharing violation"; break;
	case 0x0013: errstr = "Communication error"; break;
	case 0x0017: errstr = "Reader unavailable"; break;
	case 0x0069: errstr = "Removed card"; break;
	}
    }

    len = _snprintf(str, 256, "PCSC failed with 0x%X: ", err);
    if (errstr == NULL){
	len += _snprintf(str + len, 256 - len, "0x%X ", (err & 0xFFFF));
    }else{
	len += _snprintf(str + len, 256 - len, "%s ", errstr);
    }
    len += _snprintf(str + len, 256 - len, "(%s,%c%c,", sev[(err >> 30) & 3],
		     (err & 0x20000000) ? 'C' : '-',
		     (err & 0x10000000) ? 'R' : '-');
    if ((err & 0xfff0000) == 0x100000){
	_snprintf(str + len, 256 - len, "%s)", "(SCard)");
    }else{
	if ((err & 0xfff0000) == 0x0){
	    _snprintf(str + len, 256 - len, "%s)", "(System)");
	}else{
	    _snprintf(str + len, 256 - len, "Facility 0x%X)", ((err >> 16) & 0xFFF));
	}
    }
    str[len] = 0;
#else
    // debuglog.c() in pcsclite must be fixed for invalid error codes.
    LPSTR str = pcsc_stringify_error((LONG) err);
#endif

    return (*env)->NewStringUTF(env, str);
}
