#include "jpcsc.h"

JNIEXPORT jint JNICALL GEN_FUNCNAME(Card_NativeDisconnect)
  (JNIEnv *env, jobject _this, jint param)
{
    SCARDHANDLE card;

    card = (SCARDHANDLE) (*env)->GetLongField(env, _this, cardField);

    return SCardDisconnect(card, param);
}

JNIEXPORT jbyteArray JNICALL GEN_FUNCNAME(Card_NativeTransmit___3BII)
  (JNIEnv *env, jobject _this, jbyteArray jin, jint joff, jint jlen)
{
    SCARD_IO_REQUEST sendPci;
    SCARDHANDLE card;
    char *cin;
    jboolean isCopy = 0;
    LONG rv;
    int proto;
    char cout[256];
    DWORD clen = 256;
    jbyteArray jout;

    card = (SCARDHANDLE) (*env)->GetLongField(env, _this, cardField);
    proto = (int) (*env)->GetIntField(env, _this, protoField);

    sendPci.dwProtocol = proto;
    sendPci.cbPciLength = sizeof(SCARD_IO_REQUEST);

    cin = (*env)->GetByteArrayElements(env, jin, &isCopy);

    rv =  SCardTransmit(card, &sendPci, cin + joff, jlen, NULL, cout, &clen);

    (*env)->ReleaseByteArrayElements(env, jin, cin, JNI_ABORT);

    if (rv != SCARD_S_SUCCESS){
#ifdef DEBUG
	fprintf(stderr, "NativeTransmit(): error 0x%x\n", rv);
#endif
	return NULL;
    }

    jout = (*env)->NewByteArray(env, clen);
    (*env)->SetByteArrayRegion(env, jout, 0, clen, cout);

    return jout;
}

JNIEXPORT jint JNICALL GEN_FUNCNAME(Card_NativeTransmit___3BII_3BI)
  (JNIEnv *env, jobject _this, jbyteArray jin, jint inoff, jint inlen, jbyteArray jout, jint outoff)
{
    SCARD_IO_REQUEST sendPci;
    SCARDHANDLE card;
    char *cin;
    char *cout;
    jboolean isCopy;
    LONG rv;
    int proto;
    DWORD outlen;

    card = (SCARDHANDLE) (*env)->GetLongField(env, _this, cardField);
    proto = (int) (*env)->GetIntField(env, _this, protoField);

    sendPci.dwProtocol = proto;
    sendPci.cbPciLength = sizeof(SCARD_IO_REQUEST);

    cin = (*env)->GetByteArrayElements(env, jin, &isCopy);
    cout = (*env)->GetByteArrayElements(env, jout, &isCopy);
    outlen = (*env)->GetArrayLength(env, jout) - outoff;
    
    rv =  SCardTransmit(card, &sendPci, cin + inoff, inlen, NULL, cout + outoff, &outlen);

    (*env)->ReleaseByteArrayElements(env, jin, cin, JNI_ABORT);
    (*env)->ReleaseByteArrayElements(env, jout, cout, 0);

    if (rv != SCARD_S_SUCCESS){
	pcscex_throw(env, PCSC_EX_CLASSNAME, "SCardTransmit(): failed !");
    }
    fprintf(stderr, "transmit: return \n");
    return outlen;
}




JNIEXPORT jint JNICALL GEN_FUNCNAME(Card_NativeStatus)
 (JNIEnv *env, jobject _this, jobject jrstate)
{
    SCARDHANDLE card;
    char rdrname[256];
    jbyteArray jatr;
    DWORD rdrlen = 256;
    DWORD pdwState;
    DWORD pdwProto;
    char pbAtr[64];
    DWORD pcbAtrLen = 64;
    LONG rv;

    card = (SCARDHANDLE) (*env)->GetLongField(env, _this, cardField);

    rv = SCardStatus(card, &rdrname[0], &rdrlen, &pdwState, &pdwProto, &pbAtr[0], &pcbAtrLen);
    if (rv != SCARD_S_SUCCESS){
	return rv;
    }

    (*env)->SetIntField(env, jrstate, currentStateField, pdwState);
    (*env)->SetIntField(env, jrstate, protoStateField, pdwProto);

    (*env)->SetObjectField(env, jrstate, readerStateField, (*env)->NewStringUTF(env, rdrname));

    jatr = (*env)->NewByteArray(env, pcbAtrLen);
    (*env)->SetByteArrayRegion(env, jatr, 0, pcbAtrLen, pbAtr);
    (*env)->SetObjectField(env, jrstate, atrStateField, jatr);

    return rv;
}


JNIEXPORT jint JNICALL GEN_FUNCNAME(Card_NativeBeginTransaction)
 (JNIEnv *env, jobject _this)
{
    SCARDHANDLE card;

    card = (SCARDHANDLE) (*env)->GetLongField(env, _this, cardField);

    return SCardBeginTransaction(card);
}


JNIEXPORT jint JNICALL GEN_FUNCNAME(Card_NativeEndTransaction)
 (JNIEnv *env, jobject _this, jint dispo)
{
    SCARDHANDLE card;

    card = (SCARDHANDLE) (*env)->GetLongField(env, _this, cardField);

    return SCardEndTransaction(card, dispo);
}


JNIEXPORT jint JNICALL GEN_FUNCNAME(Card_NativeReconnect)
 (JNIEnv *env, jobject _this, jint dwSharedMode, jint dwPreferredProtos, jint dwInit)
{
    SCARDHANDLE card;
    DWORD proto;
    LONG rv;

    card = (SCARDHANDLE) (*env)->GetLongField(env, _this, cardField);

    rv = SCardReconnect(card, (DWORD) dwSharedMode, (DWORD) dwPreferredProtos, 
			(DWORD) dwInit, &proto);
    if (rv != SCARD_S_SUCCESS){
	return rv;
    }
    
    (*env)->SetIntField(env, _this, protoField, proto);
    return rv;
}



JNIEXPORT jbyteArray JNICALL GEN_FUNCNAME(Card_NativeControl___I3BII)
  (JNIEnv *env, jobject _this, jint jcc, jbyteArray jin, jint joff, jint jlen)
{
    SCARDHANDLE card;
    char *cin;
    jboolean isCopy;
    char cout[256];
    DWORD clen = 256;
    jbyteArray jout;
    LONG rv;

    card = (SCARDHANDLE) (*env)->GetLongField(env, _this, cardField);

    cin = (*env)->GetByteArrayElements(env, jin, &isCopy);

#ifndef WIN32
    rv =  SCardControl(card, cin + joff, jlen, cout, &clen);
#else
    rv =  SCardControl(card, jcc, cin + joff, jlen, cout, clen, &clen);
#endif

    (*env)->ReleaseByteArrayElements(env, jin, cin, JNI_ABORT);

    if (rv != SCARD_S_SUCCESS){
	return NULL;
    }

    jout = (*env)->NewByteArray(env, clen);
    (*env)->SetByteArrayRegion(env, jout, 0, clen, cout);

    return jout;
}




