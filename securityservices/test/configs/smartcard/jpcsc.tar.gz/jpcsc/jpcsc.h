#ifndef _jpcsc_h
#define _jpcsc_h


#include <stdio.h>
#include <assert.h>
#include <jni.h>

#include <winscard.h>

#ifdef LINUX
#include <pcsclite.h>
#endif /* LINUX */

extern jfieldID ctxField;
extern jfieldID cardField;
extern jfieldID protoField;

extern jfieldID readerStateField;
extern jfieldID currentStateField;
extern jfieldID eventStateField;
extern jfieldID atrStateField;
extern jfieldID protoStateField;

#include "built/gen1.h"
#include "built/gen2.h"

/*
 * Numbers of readers supported in GetStatusChange() and
 * ListReaders().
 */
#define JPCSC_MAX_RDRS 32

/*
 * Length of ATR.
 */
#define JPCSC_ATR_SIZE SCARD_ATR_LENGTH 

/*
 * Name of NullPointerException
 */
#define NP_EX_CLASSNAME "java/lang/NullPointerException"

/*
 * Signal an exception of given class and set message.
 */
void pcscex_throw(JNIEnv *env, const char *cn, const char *msg);

#ifdef DEBUG
void pcsc_readerstatea_log(SCARD_READERSTATE_A *rsa);
#endif /* DEBUG */


#endif /* _jpcsc_h */
