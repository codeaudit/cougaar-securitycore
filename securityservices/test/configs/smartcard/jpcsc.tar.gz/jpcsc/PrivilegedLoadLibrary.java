package PCSC_PACKAGE_NAME;

import java.security.*;

class PrivilegedLoadLibrary implements PrivilegedAction {
  public Object run() {
    System.loadLibrary("jpcsc");
    return null;
  }
}

